# Generated code do not commit.
file(TO_CMAKE_PATH "E:\\flutter_windows_3.27.3-stable\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "E:\\tryingflappybird\\tryingflappybird" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=E:\\flutter_windows_3.27.3-stable\\flutter"
  "PROJECT_DIR=E:\\tryingflappybird\\tryingflappybird"
  "FLUTTER_ROOT=E:\\flutter_windows_3.27.3-stable\\flutter"
  "FLUTTER_EPHEMERAL_DIR=E:\\tryingflappybird\\tryingflappybird\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=E:\\tryingflappybird\\tryingflappybird"
  "FLUTTER_TARGET=E:\\tryingflappybird\\tryingflappybird\\lib\\main.dart"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=E:\\tryingflappybird\\tryingflappybird\\.dart_tool\\package_config.json"
)
