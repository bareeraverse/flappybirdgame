package com.example.tryingflappybird

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
