import 'dart:async';

import 'package:flame/collisions.dart';
import 'package:flame/components.dart';
import 'package:tryingflappybird/components/ground.dart';
import 'package:tryingflappybird/components/pipe.dart';
import 'package:tryingflappybird/constants.dart';
import 'package:tryingflappybird/game.dart';

class Bird extends SpriteComponent with CollisionCallbacks {
  /*
for bird size and pos
  */

  Bird()
      : super(
            position: Vector2(birdStartX, birdStartY),
            size: Vector2(birdWidth, birdHeight));
  double velocity = 0;
  @override
  FutureOr<void> onLoad() async {
    sprite = await Sprite.load('bird.png');
    add(RectangleHitbox());
  }

  void flap() {
    velocity = jumpStrength;
  }

  @override
  void update(double dt) {
    if (!(parent as FlappyBirdGame).gameHasStarted) {
      return; // ✅ Bird stays still before tapping
    }

    velocity += gravity * dt;
    position.y += velocity * dt;

    if (position.y < 0) {
      position.y = 0;
      velocity = 0; // Optional: Stop upward movement instantly
    }
  }

  void reset() {
    position = Vector2(birdStartX, birdStartY);
    velocity = 0;
  }

  @override
  void onCollision(Set<Vector2> intersectionPoints, PositionComponent other) {
    super.onCollision(intersectionPoints, other);
    if (other is Ground) {
      (parent as FlappyBirdGame).gameOver();
    }
    if (other is Pipe) {
      (parent as FlappyBirdGame).gameOver();
    }
  }
}
