import 'dart:math'; // ✅ Needed for Random()

import 'package:flame/components.dart';
import 'package:tryingflappybird/components/pipe.dart';
import 'package:tryingflappybird/constants.dart';
import 'package:tryingflappybird/game.dart';

class PipeManager extends Component with HasGameRef<FlappyBirdGame> {
  double pipeSpawnTimer = 0;
  bool isSpawning = false;

  @override
  void update(double dt) {
    // ✅ Remove pipes properly to avoid memory leaks
    removeWhere((component) {
      if (component is Pipe && component.position.x + component.width < 0) {
        component.removeFromParent();
        return true;
      }
      return false;
    });

    if (!isSpawning) return;
    pipeSpawnTimer += dt;

    if (pipeSpawnTimer > pipeInterval) {
      pipeSpawnTimer = 0;
      spawnPipe();
    }
  }

  void startSpawning() {
    isSpawning = true;
  }

  void stopSpawning() {
    isSpawning = false;
    clearPipes(); // ✅ Clears all pipes when the game resets
  }

  void clearPipes() {
    removeWhere((component) => component is Pipe); // ✅ Removes all pipes
  }

  void spawnPipe() {
    if (!isSpawning) return;
    final double screenHeight = gameRef.size.y;

    const double minPipeHeight = 50;
    const double pipeWidth = 60;

    final double maxPipeHeight =
        screenHeight - groundHeight - pipeGap - minPipeHeight;

    final double bottomPipeHeight =
        minPipeHeight + Random().nextDouble() * (maxPipeHeight - minPipeHeight);

    final double topPipeHeight =
        screenHeight - groundHeight - bottomPipeHeight - pipeGap;

    final bottomPipe = Pipe(
        Vector2(gameRef.size.x, screenHeight - groundHeight - bottomPipeHeight),
        Vector2(pipeWidth, bottomPipeHeight),
        isTopPipe: false);

    final topPipe = Pipe(
        Vector2(gameRef.size.x, 0), Vector2(pipeWidth, topPipeHeight),
        isTopPipe: true);
    gameRef.add(bottomPipe);
    gameRef.add(topPipe);
  }
}
