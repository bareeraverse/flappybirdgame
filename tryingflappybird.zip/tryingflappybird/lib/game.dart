import 'dart:async';
import 'dart:io';
import 'package:flame/collisions.dart';
import 'package:flame/events.dart';
import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tryingflappybird/components/bg.dart';
import 'package:tryingflappybird/components/bird.dart';
import 'package:tryingflappybird/components/ground.dart';
import 'package:flame_audio/flame_audio.dart';
import 'package:tryingflappybird/components/pipe_manager.dart';
import 'package:tryingflappybird/components/score.dart';
import 'package:tryingflappybird/constants.dart';

import 'components/pipe.dart';

class FlappyBirdGame extends FlameGame with TapDetector, HasCollisionDetection {
/*
- bird
- bg
-ground
-pipes
-score
*/
  late Bird bird;
  late Background background;
  late Ground ground;
  late PipeManager pipeManager;
  late ScoreText scoreText;

  int score = 0;
  int highScore = 0;
  bool isGameOver = false;
  bool gameHasStarted = false;

  @override
  FutureOr<void> onLoad() async {
    background = Background(size);
    add(background);

    bird = Bird();
    add(bird);
    ground = Ground();
    add(ground);

    pipeManager = PipeManager();
    add(pipeManager);
    scoreText = ScoreText();
    add(scoreText);

    await _loadHighScore();

    FlameAudio.audioCache.loadAll(['flap.wav', 'hit.wav', 'point.wav']);

    // ignore: unused_element
    void playSound(String soundName) {
      FlameAudio.play(soundName); // ✅ Reuse sounds instead of reloading
    }
  }

  @override
  void update(double dt) {
    super.update(dt);

    // ✅ Debugging: Check RAM usage
    print("Current RAM Usage: ${ProcessInfo.currentRss ~/ (1024 * 1024)} MB");
  }

  void startGame() {
    gameHasStarted = true;
    isGameOver = false;
    pipeManager.startSpawning();
    bird.flap(); // ✅ Now the bird moves only after the first tap
  }

  @override
  void onTap() {
    if (!gameHasStarted) {
      startGame();
    } else {
      FlameAudio.play('flap.wav'); // Play sound when tapping
      bird.flap();
    }
  }

  void incrementScore() {
    FlameAudio.play('point.wav');
    score += 1;
  }

  Future<void> _loadHighScore() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    highScore = prefs.getInt('highScore') ?? 0;
  }

  Future<void> _updateHighScore() async {
    if (score > highScore) {
      highScore = score;
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setInt('highScore', highScore);
    }
  }

  /*
  game over */
  bool gameOverFlag = false;
  void gameOver() {
    if (gameOverFlag) return;
    gameOverFlag = true;
    gameHasStarted = false;
    FlameAudio.play('hit.wav');
    _updateHighScore();
    pauseEngine();
    if (buildContext != null) {
      showDialog(
        context: buildContext!,
        barrierDismissible: false, // ✅ Prevents accidental dismiss
        builder: (context) => AlertDialog(
          title: const Text("Game Over"),
          content: Text("Score: $score\nHigh Score: $highScore"),
          actions: [
            Row(
              // ✅ Arrange buttons in a row
              mainAxisAlignment:
                  MainAxisAlignment.spaceBetween, // ✅ Left & right alignment
              children: [
                TextButton(
                  onPressed: () {
                    exit(0); // ✅ Exit the app
                  },
                  child: const Text("Exit"),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.pop(context); // ✅ Close the dialog
                    Future.delayed(
                        Duration.zero, resetGame); // ✅ Restart the game
                  },
                  child: const Text("Restart"),
                ),
              ],
            ),
          ],
        ),
      );
    }
  }

  void resetGame() {
    bird.reset();
    bird.position = Vector2(birdStartX, birdStartY);
    bird.velocity = 0;
    score = 0;
    gameOverFlag = false;
    gameHasStarted = false;

    pipeManager.stopSpawning();
    pipeManager.clearPipes();

    pipeManager.stopSpawning();
    // Remove all pipes
    children.whereType<Pipe>().forEach((pipe) => pipe.removeFromParent());

    pipeManager = PipeManager();
    add(pipeManager);

    // Reset ground position (if needed)
    ground.position.x = 0;

    // Ensure collision system resets
    removeAll(children.whereType<RectangleHitbox>());
    bird.add(RectangleHitbox());

    resumeEngine();
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);

    if (!gameHasStarted) {
      TextPainter tp = TextPainter(
        text: TextSpan(
          text: "Tap to Start",
          style: TextStyle(color: Colors.white, fontSize: 24),
        ),
        textDirection: TextDirection.ltr,
      );
      tp.layout();
      tp.paint(canvas,
          Offset(size.x / 2 - tp.width / 2, size.y / 2 - tp.height / 2));
    }
  }
}
