const double birdStartX = 100;
const double birdStartY = 100;
const double birdWidth = 60;
const double birdHeight = 40;
const double gravity = 600;
const double jumpStrength = -300;
const double groundHeight = 200;
const double groundScrollingSpeed = 100;
const double pipeInterval = 2.5;
const double pipeGap = 150;
const double minPipeHeight = 50;
const double pipeWidth = 60;
const double pipeSpeed = 150; // ⬅️ Adjust if necessary (higher = faster pipes)
